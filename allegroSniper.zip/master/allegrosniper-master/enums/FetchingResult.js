const FetchingResult = {
  PRICE_CHECKED: 'priceChecked',
  TOO_EXPENSIVE: 'tooExpensive',
  FETCHING_ERROR: 'fetchingError',
  BUYING_ERROR: 'error',
  SUCCESSFULY_BOUGHT: 'success'
};

module.exports = FetchingResult;
