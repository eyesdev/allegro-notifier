const trimEach = arr => {
  return arr.map(el => el.trim());
};

module.exports = trimEach;
